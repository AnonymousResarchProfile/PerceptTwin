ai2thor_actions_list = ["GoToObject <object>", "OpenObject <object>", "CloseObject <object>",
                   "BreakObject <object>", "SliceObject <object>", "SwitchOn <object>",
                   "SwitchOff <object>", "CleanObject <object>", "PickupObject <object>",
                   "PutObject <object><receptacleObject>", "PutObjectIn <object><receptacleObject>",
                    "AbortPlan <reason>"] #, "DropHandObject <robot><object>",  "PushObject <robot><object>", "PullObject <robot><object>"]
